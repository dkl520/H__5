# vue-drag
vue drag with html5 drag api
